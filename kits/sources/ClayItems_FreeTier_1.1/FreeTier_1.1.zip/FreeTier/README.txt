Recommended format: glTF

Albedo texture:
Connect to Base Color / Albedo.

Normal texture:
Import as a normal map and use a strength/scale of 0.35.

Roughness texture:
Connect to Roughness using Non-Color/Linear data.

FBX and OBJ importers may not preserve every PBR material property.
All required texture maps are included for manual assignment.