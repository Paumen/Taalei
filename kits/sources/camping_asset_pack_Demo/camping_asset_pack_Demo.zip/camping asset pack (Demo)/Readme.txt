# Low Poly Camping Asset Pack - Demo

Thank you for downloading the Low Poly Camping Asset Pack Demo!

## Included Assets

This demo includes 8 assets from the full pack:

* Tent
* Campfire
* Axe
* Tree
* Rock
* Log
* Firewood
* Table


* FBX format only (upgrade to get .blend file)


## Full Version

The full version contains many additional camping-themed assets, including:

* Multiple tent variations
* Backpack
* Additional rocks and props
* Camp furniture
* Decorative assets
* Future content updates

Existing buyers of the full version will receive future updates at no additional cost.

## Support

If you encounter any issues or have suggestions for future updates, feel free to leave a comment on the asset page.

Thank you for your support!

Voxel_dev

